"""
Hermes-style 工具自注册表
Phase 1: 框架就绪，无具体工具
Phase 2: feishu_tools / game_tools / memory_tools 导入后自动注册
"""
from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

logger = logging.getLogger("tools.registry")


@dataclass
class ToolEntry:
    name: str
    description: str
    input_schema: dict
    handler: Callable
    # GBrain Minion 路由：True → asyncio 队列，False → 直接执行
    is_deterministic: bool = False
    # 允许使用此工具的角色（空列表 = 所有角色）
    allowed_roles: list[str] = field(default_factory=list)


class ToolRegistry:
    _instance: Optional["ToolRegistry"] = None

    def __init__(self):
        self._tools: dict[str, ToolEntry] = {}

    @classmethod
    def get(cls) -> "ToolRegistry":
        if cls._instance is None:
            cls._instance = ToolRegistry()
        return cls._instance

    def register(
        self,
        name: str,
        description: str,
        input_schema: dict,
        is_deterministic: bool = False,
        allowed_roles: list[str] | None = None,
    ):
        """装饰器：工具自注册"""
        def decorator(fn: Callable) -> Callable:
            self._tools[name] = ToolEntry(
                name=name,
                description=description,
                input_schema=input_schema,
                handler=fn,
                is_deterministic=is_deterministic,
                allowed_roles=allowed_roles or [],
            )
            logger.debug("注册工具：%s (deterministic=%s)", name, is_deterministic)
            return fn
        return decorator

    def get_definitions(self, role: str = "admin") -> list[dict]:
        """返回 Anthropic tool_use 格式的工具定义列表"""
        tools = []
        for entry in self._tools.values():
            if entry.allowed_roles and role not in entry.allowed_roles:
                continue
            tools.append({
                "name": entry.name,
                "description": entry.description,
                "input_schema": entry.input_schema,
            })
        return tools

    def get_for_role(self, role: str) -> list[dict]:
        return self.get_definitions(role=role)

    async def dispatch(self, name: str, inputs: dict[str, Any]) -> Any:
        """执行工具调用"""
        entry = self._tools.get(name)
        if entry is None:
            return {"error": f"工具 {name!r} 不存在"}
        try:
            if asyncio.iscoroutinefunction(entry.handler):
                return await entry.handler(**inputs)
            return entry.handler(**inputs)
        except Exception as exc:
            logger.exception("工具 %s 执行失败", name)
            return {"error": str(exc)}

    @property
    def tool_names(self) -> list[str]:
        return list(self._tools.keys())


# 模块级单例
registry = ToolRegistry.get()
