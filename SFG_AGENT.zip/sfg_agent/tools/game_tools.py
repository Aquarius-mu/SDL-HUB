"""
游戏服务器工具集（Phase 2）
gm_server MCP 的 5 个工具包装为 agent tools
"""
from __future__ import annotations

# TODO: Phase 2 实现
# 工具使用 @registry.register() 自注册，导入本模块后自动生效
#
# 计划实现（对应 gm_server MCP tools）：
#   list_zones(name_filter)                  查询区服列表
#   search_gm_commands(keyword)              搜索 GM 指令
#   send_gm_command(zone_id, command, ...)   发送 GM 指令
#   batch_send_gm_command(zone_ids, ...)     批量发送 GM 指令（admin only）
#   copy_role(...)                           角色跨服复制（admin only）
#
# 权限：
#   send/batch/copy → allowed_roles=["admin"]
#   list/search     → allowed_roles=["admin", "operator", "viewer"]
#
# 所有 GM 操作写入 audit log（~/sfg_agent/data/audit.log）
#
# gm_server config: ~/.claude/mcp-servers/gm_server/config.json
