"""
记忆工具集（Phase 3）
GBrain brain-ops: remember / recall / search_memory
"""
from __future__ import annotations

# TODO: Phase 3 实现
# 工具使用 @registry.register() 自注册，导入本模块后自动生效
#
# 计划实现：
#   remember(content, tags)           主动存储长期记忆
#   recall(query, top_k)              检索相关记忆（混合检索）
#   search_memory(query)              搜索记忆库
#   forget(memory_id)                 删除指定记忆
#
# 后端：storage/memory_store.py（SQLite FTS5 + 可选向量）
# 检索：向量 + keyword + RRF 融合（GBrain 混合检索方案）
