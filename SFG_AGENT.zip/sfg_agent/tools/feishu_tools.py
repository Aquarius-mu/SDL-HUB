"""
飞书工具集（Phase 2）
lark-cli 包装：搜群/查用户/发消息/读表格等
"""
from __future__ import annotations

# TODO: Phase 2 实现
# 工具使用 @registry.register() 自注册，导入本模块后自动生效
#
# 计划实现：
#   search_feishu_group(query)      搜索群组，返回 chat_id + 名称
#   get_user_info(open_id)          查询用户姓名/部门/邮箱
#   send_message(chat_id, text)     发送文本消息到指定群
#   search_bitable(query)           搜索多维表格
#   read_bitable_records(...)       读取多维表格记录
#
# 参考 feishu-lark-cli SKILL.md 中的命令格式
