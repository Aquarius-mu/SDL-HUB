"""
GBrain-style Skillify：自动技能生命周期
Phase 1: 占位实现
Phase 3: Haiku 驱动的技能提炼 + 10-item 审计
"""
from __future__ import annotations

import logging

logger = logging.getLogger("skills.skillify")


class Skillify:
    """
    Phase 3 实现计划：
    1. Haiku 快速判断（$0.001/次）：对话是否包含值得记录的新模式
    2. 提取新知识：lark-cli 用法、卡片组件、GM 指令套路
    3. 10-item 审计：frontmatter、triggers、quality gates
    4. 写入对应 SKILL.md（只追加，不覆盖）
    5. check-resolvable：验证技能树完整性（MECE、DRY、无孤立节点）
    """

    async def maybe_skillify(self, user_msg: str, assistant_msg: str) -> None:
        # Phase 1: 占位，无操作
        pass
