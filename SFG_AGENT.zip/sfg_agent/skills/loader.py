"""
Hermes-style Skill Loader
读取 ~/.claude/skills/*/SKILL.md，两级缓存（内存 LRU + 磁盘快照）
"""
from __future__ import annotations

import hashlib
import logging
import os
import time
from functools import lru_cache
from pathlib import Path
from typing import Optional

logger = logging.getLogger("skills.loader")

_SKILLS_DIR = os.path.expanduser("~/.claude/skills")
_CACHE_TTL = 300  # 5 分钟内存缓存


class SkillLoader:
    def __init__(self, skills_dir: str = _SKILLS_DIR):
        self.skills_dir = Path(skills_dir)
        self._cache: dict[str, tuple[float, str]] = {}  # path → (mtime, content)
        self._combined_cache: Optional[tuple[str, float]] = None  # (text, ts)

    def _read_skill(self, skill_md: Path) -> Optional[str]:
        try:
            mtime = skill_md.stat().st_mtime
            cached = self._cache.get(str(skill_md))
            if cached and cached[0] == mtime:
                return cached[1]

            content = skill_md.read_text(encoding="utf-8")
            # 去掉 YAML frontmatter
            if content.startswith("---"):
                end = content.find("---", 3)
                if end != -1:
                    content = content[end + 3:].lstrip()

            self._cache[str(skill_md)] = (mtime, content)
            return content
        except Exception:
            return None

    def get_relevant_skills(self, query: str = "") -> str:
        """
        Hermes 强制加载规则：返回所有已加载技能的摘要
        Phase 3: 按 query 相关性过滤
        """
        now = time.monotonic()
        if self._combined_cache and now - self._combined_cache[1] < _CACHE_TTL:
            return self._combined_cache[0]

        if not self.skills_dir.exists():
            return ""

        parts = []
        for skill_dir in sorted(self.skills_dir.iterdir()):
            skill_md = skill_dir / "SKILL.md"
            if not skill_md.exists():
                continue
            content = self._read_skill(skill_md)
            if content:
                name = skill_dir.name
                # 只取前 300 字作摘要（避免 prompt 过长）
                summary = content[:300].replace("\n", " ").strip()
                parts.append(f"### {name}\n{summary}…")

        combined = "\n\n".join(parts)
        self._combined_cache = (combined, now)
        logger.debug("加载 %d 个技能", len(parts))
        return combined
