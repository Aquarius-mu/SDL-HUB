# SFG_AGENT

**飞书群原生 AI 游戏运营助手** · 基于 Anthropic SDK · 专为游戏服务器团队设计

[![Python](https://img.shields.io/badge/Python-3.11+-3776AB?logo=python&logoColor=white)](https://python.org)
[![Anthropic](https://img.shields.io/badge/Claude-Sonnet_4.6-blueviolet?logo=anthropic)](https://anthropic.com)
[![License](https://img.shields.io/badge/License-MIT-22c55e)](LICENSE)
[![lark-cli](https://img.shields.io/badge/lark--cli-1.0+-f97316)](https://github.com/larksuite/lark-cli)
[![asyncio](https://img.shields.io/badge/asyncio-concurrent-06b6d4)](https://docs.python.org/3/library/asyncio.html)

---

在飞书群里 @Bot，即可让 Claude 帮你查询区服、发 GM 指令、搜索数据、操作飞书文档，并通过持续学习变得越来越懂你的项目。

```
你：@Bot 帮我查一下开发服1区的在线人数
Bot：[调用 list_zones → send_gm_command]
     1区当前在线：142人，峰值：389人（今日 20:35）
```

---

## 为什么选择 SFG_AGENT？

旧的飞书机器人（`lark_sweet_bot.sh`）是 700 行 bash，每次对话都要冷启动 `claude --resume`，无工具体系、无记忆、无权限管理。

SFG_AGENT 将它重写为 Python，融合三个 2025-2026 前沿 Agent 框架的核心创新：

| 框架 | 借鉴的核心设计 | 带来的改变 |
|------|--------------|-----------|
| **Hermes Agent** | 闭环技能学习 · 轨迹压缩 · 平台感知 Prompt | 技能自动进化；长对话不溢出 |
| **GBrain** | Minion 路由 · 混合检索 · Skillify 生命周期 · Dream 周期 | 确定性任务零成本；记忆检索 P@5 +31.4% |
| **OpenClaw** | Thinking Level · 沙箱权限 · 多通道抽象 | `/think high` 深度推理；角色级工具隔离 |

---

## 功能特性

| 功能 | 说明 |
|------|------|
| 🎮 **游戏运维** | 查区服、发 GM 指令、复制角色、批量广播 |
| 🧠 **长期记忆** | 向量 + FTS5 混合检索，跨重启保持上下文 |
| 🔧 **原生 Tool Use** | Anthropic SDK 原生循环，Claude 自主决定调哪些工具 |
| ⚡ **Minion 路由** | 确定性任务走 asyncio 队列（$0 · 100% 成功率）|
| 📚 **自进化技能** | Skillify 提炼每次对话的新模式，写入技能库 |
| 🌙 **Dream 周期** | 每晚自动修复记忆、刷新向量、清理孤立节点 |
| 🔐 **三级权限** | open_id 白名单 + admin / operator / viewer 角色 |
| 💭 **思考深度控制** | `/think high` 开启 extended thinking，复杂分析更准 |

---

## 架构概览

```
飞书群消息 (@Bot)
       │
       ▼
 gateway/feishu.py          # lark-cli 事件订阅 → asyncio Queue
       │
       ▼
 handlers/mention.py        # 权限检查 → slash 分流 → 并发发卡片
       │
       ▼
 agent/orchestrator.py      # Hermes + GBrain + OpenClaw 融合 loop
 ┌──────────────────────────────────────────┐
 │  memory_manager   GBrain 混合记忆预取     │
 │  prompt_builder   飞书平台提示 + 技能注入  │
 │  context_engine   轨迹压缩 (>40 条触发)   │
 │  thinking         /think level 配置       │
 └──────────────────────────────────────────┘
       │  tool_use loop (max 20 轮)
       ▼
 tools/registry.py          # 自注册工具表 + GBrain Minion 路由
 ├── feishu_tools            # lark-cli：搜群/查用户/发消息
 ├── game_tools              # gm_server HTTP：GM指令/区服/角色
 ├── memory_tools            # remember / recall / search
 └── minion_tools            # 确定性任务 → asyncio 队列
       │
       ▼
 gateway/card.py             # Python CardBuilder (schema 2.0)
       │
       ▼
    飞书卡片回复（支持流式思考态 → 原地更新为最终答案）
```

---

## 快速开始

### 前置条件

| 依赖 | 版本 | 安装方式 |
|------|------|---------|
| Python | 3.11+ | `uv python install 3.12` |
| [uv](https://docs.astral.sh/uv/) | 任意 | `curl -LsSf https://astral.sh/uv/install.sh \| sh` |
| lark-cli | 1.0+ | `npm install -g @larksuite/lark-cli` |
| 飞书 Bot Token | 已配置 | `lark-cli auth login --as bot` |

### 一键安装

```bash
# 解压后进入目录
unzip SFG_AGENT.zip && cd sfg_agent

# 自动检测 Python / lark-cli，创建 venv，安装依赖
bash install.sh
```

### 配置

```bash
# 交互式向导（推荐首次使用）
./run.sh setup

# 或手动复制模板
cp config.example.yaml config.yaml
```

最少只需填写以下 4 项即可启动：

```yaml
anthropic:
  api_key: "${ANTHROPIC_AUTH_TOKEN}"   # 支持环境变量引用
  base_url: "${ANTHROPIC_BASE_URL}"    # 兼容私有代理端点

lark:
  bot_open_id: "ou_xxx"               # Bot 的 open_id

permissions:
  whitelist:
    - open_id: "ou_你的open_id"
      name: "你的名字"
      roles: ["admin"]
```

### 启动

```bash
./run.sh start        # 后台启动
./run.sh status       # 查看状态
./run.sh logs         # 实时日志
./run.sh stop         # 停止
```

---

## 使用指南

### 对话示例

```
@Bot 1区今天有没有异常充值？
@Bot 帮我把测试服角色"剑士123"复制到1区
@Bot 搜一下"发版通知"群的 chat_id
@Bot 查一下 uid=88888 玩家的上次登录时间
```

### 斜杠命令

| 命令 | 说明 |
|------|------|
| `/clear` | 清除当前会话，开启新对话 |
| `/think high` | 开启 extended thinking（复杂分析） |
| `/think low` | 关闭深度推理（普通对话，更快） |
| `/compact` | 压缩过长的对话历史 |
| `/stats` | 查看本群对话统计 |
| `/help` | 显示帮助 |

### 权限说明

| 角色 | 可用功能 |
|------|---------|
| `admin` | 全部功能，含批量 GM 指令、角色复制 |
| `operator` | 查询类 GM 指令、飞书操作、记忆读写 |
| `viewer` | 查区服列表、普通对话 |

修改 `config.yaml` 中的 `whitelist` 后无需重启即可生效。

---

## 配置参考

```yaml
anthropic:
  api_key: "${ANTHROPIC_AUTH_TOKEN}"
  base_url: "${ANTHROPIC_BASE_URL}"
  model: "claude-sonnet-4-6"
  max_tokens: 4096

lark:
  bot_open_id: "ou_xxx"
  lark_cli_path: ""                  # 留空则自动检测

thinking:
  default_level: "low"               # low / medium / high
  auto_upgrade_threshold: 500        # 消息超过 N 字自动升级到 medium

memory:
  enabled: true
  vector_enabled: false              # 需要 sentence-transformers（400MB）
  ttl_days: 90

dream:
  enabled: true
  cron: "0 3 * * *"                 # 每天凌晨 3 点

game:
  enabled: true
  gm_server_config: "~/.claude/mcp-servers/gm_server/config.json"
  audit_log: "~/sfg_agent/data/audit.log"
```

---

## 项目结构

```
sfg_agent/
├── main.py                # CLI 入口：start / stop / restart / status / setup
├── config.yaml            # 运行配置（不纳入 git）
├── config.example.yaml    # 配置模板
├── requirements.txt
├── install.sh             # 一键安装脚本
│
├── agent/
│   ├── orchestrator.py    # 核心 Agent Loop（Hermes + GBrain + OpenClaw）
│   ├── memory_manager.py  # GBrain 三层记忆编排
│   ├── prompt_builder.py  # 平台感知 + 技能强制注入
│   ├── context_engine.py  # 轨迹压缩
│   └── thinking.py        # /think level 控制
│
├── tools/
│   ├── registry.py        # 自注册工具表 + Minion 路由
│   ├── feishu_tools.py    # lark-cli 封装（Phase 2）
│   ├── game_tools.py      # gm_server HTTP 封装（Phase 2）
│   └── memory_tools.py    # 记忆工具（Phase 3）
│
├── gateway/
│   ├── feishu.py          # 事件订阅 + 异步卡片收发
│   └── card.py            # Python CardBuilder (schema 2.0)
│
├── handlers/
│   ├── mention.py         # @mention → Agent Loop
│   └── slash.py           # /clear /think /compact /stats /help
│
├── storage/
│   ├── session_store.py   # SQLite 会话历史 + 统计
│   ├── memory_store.py    # 混合检索（Phase 3）
│   └── cache_store.py     # 用户 / 群组 JSON 缓存
│
├── skills/
│   ├── loader.py          # Hermes 两级技能缓存（LRU + 磁盘）
│   └── skillify.py        # GBrain Skillify 自动生命周期（Phase 3）
│
└── data/
    ├── sfg_agent.db       # SQLite 主库
    ├── audit.log          # GM 操作审计日志
    └── cache/             # → ~/feishu_bot/cache/（兼容旧 bot）
```

---

## 开发路线

- [x] **Phase 1**：骨架（Feishu 事件监听、SDK tool_use 循环、SQLite 会话、斜杠命令、白名单）
- [ ] **Phase 2**：工具体系（feishu_tools、game_tools gm_server、Minion 队列、角色权限过滤）
- [ ] **Phase 3**：记忆与智能（向量 + FTS5 混合检索、Skillify、Dream 周期）

---

## 故障排查

**Bot 无响应**
```bash
./run.sh status
./run.sh logs
lark-cli auth login --as bot
```

**GM 指令失败**
```bash
cat ~/.claude/mcp-servers/gm_server/config.json
grep "game_tools" ~/sfg_agent/data/audit.log | tail -20
```

**从旧 lark_sweet_bot.sh 迁移**
```bash
# 缓存自动兼容（install.sh 已处理软链接）
~/lark_sweet_bot.sh stop 2>/dev/null || true
./run.sh start
```

---

## License

[MIT](LICENSE) © 2026 SFG_AGENT Contributors
