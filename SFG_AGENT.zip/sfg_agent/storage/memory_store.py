"""
GBrain-style 混合记忆存储（Phase 3）
向量搜索 + SQLite FTS5 + RRF 融合
"""
from __future__ import annotations

# TODO: Phase 3 实现
#
# 架构（GBrain HybridRetrieval）：
#   1. 意图分类（确定性）→ entity/temporal/general
#   2. entity → 图遍历（精确，零 LLM）
#   3. general →
#      a. 多查询扩展（Haiku 生成 3 个变体）
#      b. 向量搜索（HNSW cosine，sentence-transformers）
#      c. FTS5 关键词搜索（SQLite）
#      d. RRF 融合：score = Σ(1/(60+rank))
#      e. compiled_truth 提升
#
# 数据模型（GBrain MemoryItem）：
#   compiled_truth: str   当前最佳理解（可被更新）
#   timeline: list[str]  历史记录（只追加）
#   entity_type: str     person/group/concept/game_event
#   tags: list[str]
#   backlinks: list[str] 关联实体
#
# Dream 周期（夜间维护）：
#   lint_memory / sync_backlinks / synthesize /
#   refresh_embeddings / extract_patterns / audit_orphans
