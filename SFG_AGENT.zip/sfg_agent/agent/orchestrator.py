"""
SFG_AGENT 核心 Agent Loop
Hermes-style tool_use 循环 + GBrain Minion 路由 + OpenClaw Thinking Level
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from typing import Any, Optional

import anthropic

from agent.context_engine import ContextEngine
from agent.memory_manager import MemoryManager
from agent.prompt_builder import MessageContext, PromptBuilder
from agent.thinking import ThinkingManager
from tools.registry import ToolRegistry

logger = logging.getLogger("agent.orchestrator")


class Orchestrator:
    def __init__(
        self,
        config,
        session_store,
        memory_manager: MemoryManager,
        prompt_builder: PromptBuilder,
        registry: ToolRegistry,
        thinking: ThinkingManager,
        context_engine: ContextEngine,
    ):
        self.config = config
        self.session_store = session_store
        self.memory_mgr = memory_manager
        self.prompt_builder = prompt_builder
        self.registry = registry
        self.thinking = thinking
        self.context_engine = context_engine

        self.client = anthropic.AsyncAnthropic(
            api_key=os.getenv("ANTHROPIC_AUTH_TOKEN") or config.anthropic.api_key,
            base_url=os.getenv("ANTHROPIC_BASE_URL") or config.anthropic.base_url,
        )
        self.model: str = config.anthropic.model
        self.max_tokens: int = config.anthropic.max_tokens

    # ──────────────────────────────────────────────
    # 主入口
    # ──────────────────────────────────────────────

    async def run(self, user_input: str, ctx: MessageContext) -> str:
        t0 = time.monotonic()

        # ① GBrain brain-ops: 先查记忆
        memory_ctx = await self.memory_mgr.prefetch(user_input)

        # ② Hermes prompt builder
        system = self.prompt_builder.build(ctx, memory_ctx)

        # ③ OpenClaw thinking level
        thinking_cfg = self.thinking.get_config(ctx.chat_id)

        # ④ 加载对话历史
        history = await self.session_store.get_history(ctx.chat_id)
        history.append({"role": "user", "content": user_input})

        # ⑤ Hermes agent loop
        tools = self.registry.get_for_role(ctx.role)
        final_text = ""

        try:
            for _iteration in range(20):  # 最多 20 轮工具调用
                kwargs: dict[str, Any] = dict(
                    model=self.model,
                    max_tokens=self.max_tokens,
                    system=system,
                    messages=history,
                )
                if tools:
                    kwargs["tools"] = tools
                if thinking_cfg:
                    kwargs["thinking"] = thinking_cfg

                resp = await self.client.messages.create(**kwargs)
                history.append({"role": "assistant", "content": self._content_to_list(resp.content)})

                if resp.stop_reason == "end_turn" or resp.stop_reason != "tool_use":
                    final_text = self._extract_text(resp.content)
                    break

                # ⑥ GBrain Minion 路由：并发执行所有工具调用
                tool_results = await self._execute_tools_parallel(resp.content, ctx.role)
                history.append({"role": "user", "content": tool_results})

        except anthropic.APIError as exc:
            logger.error("Anthropic API 错误：%s", exc)
            return f"API 错误：{exc}"

        # ⑦ Hermes 轨迹压缩
        if self.context_engine.should_compress(history):
            history = self.context_engine.compress(history)

        # ⑧ 持久化 + 异步记忆同步
        await self.session_store.save_history(ctx.chat_id, history)
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        await self.session_store.record_stat(ctx.chat_id, elapsed_ms)
        asyncio.create_task(self.memory_mgr.sync_turn(user_input, final_text))

        logger.info(
            "[%s][%s] %d字 %.0fms",
            ctx.group_name, ctx.sender_name, len(final_text), elapsed_ms
        )
        return final_text

    # ──────────────────────────────────────────────
    # 工具执行（GBrain Minion 路由）
    # ──────────────────────────────────────────────

    async def _execute_tools_parallel(
        self, content: list, role: str
    ) -> list[dict]:
        tasks = []
        tool_use_ids = []

        for block in content:
            if hasattr(block, "type") and block.type == "tool_use":
                tool_use_ids.append(block.id)
                tasks.append(self._call_tool(block.name, block.input, role))

        if not tasks:
            return []

        results = await asyncio.gather(*tasks, return_exceptions=True)

        tool_results = []
        for tid, result in zip(tool_use_ids, results):
            if isinstance(result, Exception):
                content_str = json.dumps({"error": str(result)}, ensure_ascii=False)
            else:
                content_str = (
                    json.dumps(result, ensure_ascii=False)
                    if not isinstance(result, str)
                    else result
                )
            tool_results.append({
                "type": "tool_result",
                "tool_use_id": tid,
                "content": content_str,
            })

        return tool_results

    async def _call_tool(self, name: str, inputs: dict, role: str) -> Any:
        entry = self.registry._tools.get(name)
        if entry is None:
            return {"error": f"工具 {name!r} 未找到"}

        # 权限检查
        if entry.allowed_roles and role not in entry.allowed_roles:
            return {"error": f"权限不足：{role} 无法使用工具 {name}"}

        logger.debug("调用工具：%s %s", name, json.dumps(inputs, ensure_ascii=False)[:80])
        return await self.registry.dispatch(name, inputs)

    # ──────────────────────────────────────────────
    # 工具函数
    # ──────────────────────────────────────────────

    @staticmethod
    def _extract_text(content) -> str:
        if isinstance(content, str):
            return content
        texts = []
        for block in content:
            if hasattr(block, "type"):
                if block.type == "text":
                    texts.append(block.text)
            elif isinstance(block, dict) and block.get("type") == "text":
                texts.append(block.get("text", ""))
        return "\n".join(texts).strip()

    @staticmethod
    def _content_to_list(content) -> list:
        """把 Anthropic response content 转为可 JSON 序列化的 list"""
        if isinstance(content, list):
            result = []
            for block in content:
                if hasattr(block, "model_dump"):
                    result.append(block.model_dump())
                elif isinstance(block, dict):
                    result.append(block)
            return result
        return []
