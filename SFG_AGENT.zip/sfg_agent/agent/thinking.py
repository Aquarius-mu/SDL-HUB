"""
OpenClaw-style Thinking Level 控制
per-chat_id 配置，支持 /think low/medium/high 命令
"""
from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger("agent.thinking")

LEVELS: dict[str, Optional[dict]] = {
    "low": None,
    "medium": {"type": "enabled", "budget_tokens": 5000},
    "high": {"type": "enabled", "budget_tokens": 16000},
}


class ThinkingManager:
    def __init__(self, default_level: str = "low"):
        self._default = default_level if default_level in LEVELS else "low"
        self._overrides: dict[str, str] = {}

    def set_level(self, chat_id: str, level: str) -> bool:
        if level not in LEVELS:
            return False
        self._overrides[chat_id] = level
        logger.info("chat %s thinking → %s", chat_id, level)
        return True

    def get_level(self, chat_id: str) -> str:
        return self._overrides.get(chat_id, self._default)

    def get_config(self, chat_id: str) -> Optional[dict]:
        return LEVELS[self.get_level(chat_id)]

    def reset(self, chat_id: str) -> None:
        self._overrides.pop(chat_id, None)
