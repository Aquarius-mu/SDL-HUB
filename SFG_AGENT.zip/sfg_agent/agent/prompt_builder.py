"""
Hermes-style Prompt Builder
平台感知 system prompt + 技能强制注入 + 游戏上下文 + 记忆注入
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger("agent.prompt_builder")

_BASE_IDENTITY = """你是 SFG_AGENT，一个部署在飞书群的 AI 助手，由 Anthropic Claude 驱动。
你服务于游戏公司的 QA、运营和策划团队，可以帮助他们查询游戏数据、执行 GM 指令、操作飞书文档。"""

_FEISHU_PLATFORM = """
## 飞书平台规则（必须遵守）
- 回答使用飞书 Markdown（lark_md），不使用标准 Markdown 语法
- 卡片使用 schema 2.0；折叠面板 collapsible_panel 颜色必须带层级后缀（blue-100，不能用 blue）
- @提及语法：`<at id="ou_xxx">姓名</at>`
- Emoji 只能用官方 key：:DONE: :Loudspeaker: :Trophy: :Fire: 等，禁用 :WAITING: :PROCESSING:
- 回答超过 1500 字时，主动提示用 /compact 压缩历史
"""

_GAME_CONTEXT = """
## 游戏服务器环境
- 大型 C++ 游戏服务器（GameServer/FightServer/AllianceServer）
- 开发环境 env=d，区服 ID 为整数
- 执行 GM 指令前，先确认操作意图；危险操作（批量/复制/广播）需二次确认
- 可调用 list_zones 工具查看当前可用区服列表
"""

_SKILL_RULE = """
## 技能加载规则（强制）
以下是已加载的技能文档。**如果某个技能与当前任务相关，你必须优先参考该技能再作答，不得跳过。**
技能文档包含经过验证的最佳实践，优先级高于你的通用知识。
"""

_OPERATOR_ONLY = """
## 当前用户权限
你正在与 **{role}** 用户对话。以下工具对该用户不可用：{denied}。
如果用户请求超出权限的操作，礼貌说明并建议联系管理员。
"""


@dataclass
class MessageContext:
    chat_id: str
    sender_id: str
    sender_name: str
    role: str
    message_id: str
    group_name: str = "未知群组"
    denied_tools: list = None

    def __post_init__(self):
        if self.denied_tools is None:
            self.denied_tools = []


class PromptBuilder:
    def __init__(self, config, skill_loader=None):
        self.config = config
        self.skill_loader = skill_loader
        self._game_enabled = getattr(config.game, "enabled", False)

    def build(self, ctx: MessageContext, memory_ctx: Optional[str] = None) -> str:
        parts = [_BASE_IDENTITY]

        # 1. 飞书平台规则
        parts.append(_FEISHU_PLATFORM)

        # 2. 游戏上下文（admin/operator 才显示）
        if self._game_enabled and ctx.role in ("admin", "operator"):
            parts.append(_GAME_CONTEXT)

        # 3. 权限提示
        if ctx.denied_tools:
            denied_str = "、".join(ctx.denied_tools[:5])
            parts.append(_OPERATOR_ONLY.format(role=ctx.role, denied=denied_str))

        # 4. 技能注入（Hermes 强制加载规则）
        if self.skill_loader:
            skills_text = self.skill_loader.get_relevant_skills()
            if skills_text:
                parts.append(_SKILL_RULE + "\n" + skills_text)

        # 5. 记忆上下文
        if memory_ctx:
            parts.append(f"<memory-context>\n{memory_ctx}\n</memory-context>")

        # 6. 当前对话信息
        parts.append(
            f"## 当前对话\n"
            f"- 群组：{ctx.group_name}（chat_id: {ctx.chat_id}）\n"
            f"- 用户：{ctx.sender_name}（open_id: {ctx.sender_id}）\n"
            f"- 角色：{ctx.role}"
        )

        return "\n\n".join(parts)
