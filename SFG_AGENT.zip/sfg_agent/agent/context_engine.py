"""
Hermes-style 轨迹压缩引擎
超过 75% context 时自动触发，保留头部 + 尾部，压缩中间
Phase 1: 基础实现（消息条数限制）
Phase 3: 接入 token 计数后做精确压缩
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("agent.context")

# 保留最近 N 轮不压缩（Hermes 默认尾部保护 6 条）
_TAIL_KEEP = 6
# 头部保留（system 指令初始化轮次）
_HEAD_KEEP = 2
# 单次最多保留消息条数（Phase 1 简单实现）
_MAX_MESSAGES = 40


class ContextEngine:
    def __init__(self, max_messages: int = _MAX_MESSAGES):
        self.max_messages = max_messages

    def should_compress(self, messages: list[dict[str, Any]]) -> bool:
        return len(messages) > self.max_messages

    def compress(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """
        简单压缩：保留头 _HEAD_KEEP 条 + 尾 _TAIL_KEEP 条，中间插入摘要占位
        Phase 3: 用 Claude Haiku 生成真实摘要替换占位符
        """
        if len(messages) <= self.max_messages:
            return messages

        head = messages[:_HEAD_KEEP]
        tail = messages[-_TAIL_KEEP:]
        removed = len(messages) - _HEAD_KEEP - _TAIL_KEEP

        summary_msg = {
            "role": "user",
            "content": (
                f"[系统：以上 {removed} 条历史消息已压缩。"
                "关键信息已保留在记忆中，请继续对话。]"
            ),
        }

        compressed = head + [summary_msg] + tail
        logger.info("轨迹压缩：%d → %d 条", len(messages), len(compressed))
        return compressed
