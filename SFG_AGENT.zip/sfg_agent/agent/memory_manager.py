"""
GBrain-style 记忆管理器
Phase 1: 占位实现（无持久记忆，只返回空上下文）
Phase 3: 接入 HybridMemoryStore（向量 + FTS + RRF 混合检索）
"""
from __future__ import annotations

import logging

logger = logging.getLogger("agent.memory")


class MemoryManager:
    """
    记忆管理器接口，供 Orchestrator 调用
    Phase 1: 空实现，Phase 3 替换为 HybridMemoryStore
    """

    async def prefetch(self, query: str) -> str:
        """
        GBrain brain-ops: 检索与查询相关的历史记忆
        返回格式化的上下文字符串，注入 system prompt
        Phase 3: 混合检索（向量 + FTS + RRF）
        """
        return ""

    async def sync_turn(self, user_msg: str, assistant_msg: str) -> None:
        """
        对话结束后异步同步记忆
        Phase 3: 提炼事实 → 写入 memory_store
        """
        pass

    async def remember(self, content: str, tags: list[str] | None = None) -> bool:
        """
        工具调用：主动存储记忆
        Phase 3: 写入 SQLite FTS + 向量索引
        """
        logger.debug("remember（Phase 1 占位）: %s", content[:50])
        return True

    async def recall(self, query: str, top_k: int = 5) -> list[dict]:
        """
        工具调用：检索记忆
        Phase 3: 混合检索
        """
        return []
